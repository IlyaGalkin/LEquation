
class Line_eq
{
    public:
        Line_eq(double a, double b);
        void calculate();
    private:
        double a;
        double b;
};
