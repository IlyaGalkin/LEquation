#include <iostream>
#include "Third.h"
#include "Fourth.h"
#include <math.h>                           // for sqrt(), fabs(), pow(), cos(), acos().
#include "Complex"                          // for complex
using namespace std;
four_eq::four_eq(double a, double b, double c, double d, double e)
{
    if(a == 0)
    {
        Cube_eq objCube_eq(b, c, d, e);
        objCube_eq.calculate();
    }
    else
    {
        this->a = a;
        this->b = b;
        this->c = c;
        this->d = d;
        this->e = e;
    }
}

void four_eq::calculate2(){
    double p, q, r, z1, z2, z3;
    p=(8*a*c-3*b*b)/(8*a*a);
    q=(8*a*a*d+b*b*b-4*a*b*c)/(8*a*a*a);
    r=(16*a*b*b*b*c-64*a*a*b*d-3*b*b*b*b+256*a*a*a*e)/(256*a*a*a*a);
    //�������� ��������� ���� a*x^4+b*x^3+c*x^2+d*x+e=0 � ��������� ���� y^4+p*y^2+q*y+r=0  (������ x=y-b/4a)
    Cube_eq objCube_eq(1, p/2, (p*p-4*r)/16, -q*q/64);
    objCube_eq.calculate();
    z1=sqrt(z1); z2=sqrt(z2); z3=sqrt(z3);
    if (z1*z2*z3==-q/8)
        cout<<"Ans"<<z1*z2*z3<<endl;//1
    if ((-z1)*z2*z3==-q/8)
        cout<<"Ans"<<(-z1)*z2*z3<<endl;//2
    if (z1*(-z2)*z3==-q/8)
        cout<<"Ans"<<z1*(-z2)*z3<<endl;//3
    if (z1*z2*(-z3)==-q/8)
        cout<<"Ans"<<z1*z2*(-z3)<<endl;//4
    if ((-z1)*(-z2)*z3==-q/8)
        cout<<"Ans"<<(-z1)*(-z2)*z3<<endl;//5
    if (z1*(-z2)*(-z3)==-q/8)
        cout<<"Ans"<<z1*(-z2)*(-z3)<<endl;//6
    if ((-z1)*z2*(-z3)==-q/8)
        cout<<"Ans"<<(-z1)*z2*(-z3)<<endl;//7
    if ((-z1)*(-z2)*(-z3)==-q/8)
        cout<<"Ans"<<(-z1)*(-z2)*(-z3)<<endl;//8
}
