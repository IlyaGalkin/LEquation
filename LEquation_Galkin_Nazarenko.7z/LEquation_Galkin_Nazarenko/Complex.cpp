#include "Complex.h"
#include <iostream>

using namespace std;

Complex::Complex()
{
    a = 0;
    b = 0;
}

Complex::Complex(double a, double b)
{
    this->a = a;
    this->b = b;
}

double Complex::get_a()
{
    return a;
}

double Complex::get_b()
{
    return b;
}

void Complex::show()
{
    cout << a << " + i*" << b << endl;
}
