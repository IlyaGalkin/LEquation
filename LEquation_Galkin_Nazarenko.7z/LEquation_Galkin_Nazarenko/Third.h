#include "Complex.h"
#pragma once

class Cube_eq
{
    public:
        Cube_eq(double a, double b, double c, double d);
        void calculate();
    private:
        double a;
        double b;
        double c;
        double d;
        Complex y0, y1, y2;
};
