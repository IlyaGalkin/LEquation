#include "Third.h"
#include "Complex.h"
#include <cmath>
#include <iostream>

const double pi = 3.14;

using namespace std;


Cube_eq::Cube_eq(double a, double b, double c, double d)
{
    if(a == 0)
    {
        //
    }
    else
    {
        this->a = 1;
        this->b = b/a;
        this->c = c/a;
        this->d = d/a;
    }
}


void Cube_eq::calculate()
{

    double p=(3*c-b*b)/3;
    double q=(2*b*b*b-9*c*d+27*d)/27;
    double p3=p*p*p;
    double q2=q*q;
    double Q=p3/27+q2/8;
    if (Q<0)
    {
        double t = acos((p/3)/sqrt(p3))/3; b=b/3;
        double q=-2*sqrt(q/2);
        double x0=q*cos(t)-b;
        double x1=q*cos(t+(2*pi/3))-b;
        double x2=q*cos(t-(2*pi/3))-b;
        y0 = Complex(x0, 0);
        y1 = Complex(x1, 0);
        y2 = Complex(x2, 0);
    }
    else
    {
        double aa, bb;

        aa=pow(-q/2+sqrt(Q), 1/3);
        bb=pow(-q/2-sqrt(Q), 1/3);

        double x0=aa+bb-b/3;
        if(Q!=0)
        {
            y0 = Complex(x0, 0);
            y1 = Complex(-0.5*(aa+bb)-b/3, (sqrt(3)*0.5)*(aa-bb));
            y2 = Complex(-0.5*(aa+bb)-b/3, -(sqrt(3)*0.5)*(aa-bb));
        }
        else
        {
            y0 = Complex(x0, 0);
            y1 = Complex((-aa-bb)*0.5-b/3, 0);
            y2 = y1;
        }
    }
    y0.show();
    y1.show();
    y2.show();
}
