#include <iostream>
#include "Class2.h"
#define pi (3.141592653589793)
#include <math.h>                           // for sqrt(), fabs(), pow(), cos(), acos().
#include <complex>                          // for complex
using namespace std;
class Cube_eq
{
    public:
        Cube_eq(double a, double b, double c, double d)
        {
            this->a = a;
            this->b = b;
            this->c = c;
            this->d = d;
        }
        void calculate1()
        {
            if(a == 0){
                Quadratic_eq objQuadratic_eq(b, c, d);
                objQuadratic_eq.calculate();
            }
            else{
                b=b/a;
                c=c/a;
                d=d/a;
                double Q=(b*b-3*c)/9;
                double R=(2*b*b*b-9*c*d+27*d)/54;
                double r2=R*R;
                double q3=Q*Q*Q;s
                if(r2<q3){
                    double t=acos(R/sqrt(q3))/3; b=b/3; double q=-2*sqrt(Q);
                    cout << "������� ������" << q*cos(t)-b << endl << "������� ������" << q*cos(t+(2*pi/3))-b << endl<< "������� ������" << (q*cos(t-(2*pi/3))-b);}
                else{
                    cout<<r2 <<q3 <<endl;
                    double aa,bb, r, q;
                    if(R<=0.) r=-R;
                    aa=-pow(r+sqrt(r2-q3),1./3.);
                    if(aa!=0.) bb=q/aa;
                    else bb=0.;
                    b/=3.; q=aa+bb; r=aa-bb;
                    double x0=q-b;
                    double x1=(-0.5)*q-b;
                    double x2=(sqrt(3)*0.5)*fabs(r);
                    if(x2==0)
                        cout << "������� ������" << x0 << endl << "������� ������(complex)" << x1 << "������� ������(complex)" << x2;
                    else
                        cout << "������� ������" << x0 << endl << "������� ������" << aa-b ;
                }
            }
        }
    private:
        double a;
        double b;
        double c;
        double d;
};

int main()
{
    setlocale(LC_ALL, "Russian");
    double a, b, c, d;
    cout << "(a*x^3+b*x^2+c*x+d=o)Input a, b, c, d:";
    cin >> a >> b >> c >> d;
    Cube_eq objCube_eq(a, b, c, d);
    objCube_eq.calculate1();
    return 0;
}
