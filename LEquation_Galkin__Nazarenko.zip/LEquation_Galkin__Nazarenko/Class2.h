#include <iostream>
#include <complex>                          // for complex
#include <cmath>                            // для функции sqrt
using namespace std;
class Quadratic_eq
{
    public:
        Quadratic_eq(double a, double b, double c)
        {
            this->a = a;
            this->b = b;
            this->c = c;
        }
        void calculate()
        {
            if(a == 0){
                if(b == 0)
                    if(c == 0)
                        cout << "Бесконечность решений" << endl;
                    else
                        cout << "0 решений" << endl;
                else
                    if(c == 0)
                        cout << "0 решений" << endl;
                    else
                        cout << "Решение" << (-c)/(b) << endl;}
            else{
                double d=b*b-4*a*c;
                if(d > 0)
                    cout << "Решение первое" << (-b+sqrt(d))/(2*a) << endl << "Решение второе" << (-b-sqrt(d))/(2*a);
                if(d == 0)
                    cout << "Решение" << (-b)/(2*a);
                if(d < 0){
                    complex<double> x((-b)/(2*a), sqrt(-d)/(2*a));
                    cout << "Решение" << x;}}
        }
    private:
        double a;
        double b;
        double c;
};

