#include <iostream>
using namespace std;
class Line_eq
{
    public:
        Line_eq(double a, double b)
        {
            this->a = a;
            this->b = b;
        }
        void calculate()
        {
            if(a == 0)
                if(b == 0)
                    cout << "������������� �������" << endl;
                else
                    cout << "0 �������" << endl;
            else
                cout << "������� " << -b/a;
        }
    private:
        double a;
        double b;
};

int main()
{
    setlocale(LC_ALL, "Russian");
    double a, b;
    cout << "(a*x+b=o)Input a, b:";
    cin >> a >> b;
    Line_eq objLine_eq(a, b);
    objLine_eq.calculate();
    return 0;
}
