#pragma once

class Complex
{
    public:
        Complex();
        Complex(double, double);
        double get_a();
        double get_b();
        void show();
    private:
        double a, b;

};
