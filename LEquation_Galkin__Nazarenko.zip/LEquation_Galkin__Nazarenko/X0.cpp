#include<iostream>
#include<cmath>
using namespace std;

bool Solve(double a,double b,double &x)
{
     b=b*(-1);
     x=b/a;
     return true;
}
int main()
{
    int a, b;
    cout<<"Input a,b:";
    cin>>a>>b;
    double x=0;
    bool temp = Solve(a,b,x);
    cout<<"x = "<<x<<std::endl;
}
