#include <iostream>
#include "Class.h"
#define pi (3.141592653589793)
#include <math.h>                           // for sqrt(), fabs(), pow(), cos(), acos().
#include <complex>                          // for complex
using namespace std;
class four_eq
{
    public:
        four_eq(double a, double b, double c, double d, double e)
        {
            this->a = a;
            this->b = b;
            this->c = c;
            this->d = d;
            this->e = e;
        }
        void calculate2()
        {
            if(a == 0){
                cout<<"hi0"<<endl;
                Cube_eq objCube_eq(b, c, d, e);
                objCube_eq.calculate1();
            }
            else{
                double p, q, r, z1, z2, z3;
                p=(8*a*c-3*b*b)/(8*a*a);
                q=(8*a*a*d+b*b*b-4*a*b*c)/(8*a*a*a);
                r=(16*a*b*b*b*c-64*a*a*b*d-3*b*b*b*b+256*a*a*a*e)/(256*a*a*a*a);
                //�������� ��������� ���� a*x^4+b*x^3+c*x^2+d*x+e=0 � ��������� ���� y^4+p*y^2+q*y+r=0  (������ x=y-b/4a)
                Cube_eq objCube_eq(1, p/2, (p*p-4*r)/16, -q*q/64);
                objCube_eq.calculate1();
                z1=sqrt(z1); z2=sqrt(z2); z3=sqrt(z3);
                if (z1+z2+z3==-q/8)
                    cout<<"Ans"<<z1+z2+z3<<endl;//1
                if (-z1+z2+z3==-q/8)
                    cout<<"Ans"<<-z1+z2+z3<<endl;//2
                if (z1-z2+z3==-q/8)
                    cout<<"Ans"<<z1-z2+z3<<endl;//3
                if (z1+z2-z3==-q/8)
                    cout<<"Ans"<<z1+z2-z3<<endl;//4
                if (-z1-z2+z3==-q/8)
                    cout<<"Ans"<<-z1-z2+z3<<endl;//5
                if (z1-z2-z3==-q/8)
                    cout<<"Ans"<<z1-z2-z3<<endl;//6
                if (-z1+z2-z3==-q/8)
                    cout<<"Ans"<<-z1+z2-z3<<endl;//7
                if (-z1-z2-z3==-q/8)
                    cout<<"Ans"<<-z1-z2-z3<<endl;//8
                }
        }
    private:
        double a;
        double b;
        double c;
        double d;
        double e;
};

int main()
{
    setlocale(LC_ALL, "Russian");
    double a, b, c, d;
    cout << "(a*x^4+b*x^3+c*x^2+d*x+e=o)Input a, b, c, d, e:";
    cin >> a >> b >> c >> d >> e;
    four_eq objfour_eq(a, b, c, d);
    objfour_eq.calculate4();
    return 0;
}
