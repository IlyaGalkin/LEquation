#include <iostream>
#include "Complex.h"
#include "Third.h"

using namespace std;

int main()
{
    Cube_eq a(1, 1, 1, 1);
    a.calculate();
    return 0;
}
