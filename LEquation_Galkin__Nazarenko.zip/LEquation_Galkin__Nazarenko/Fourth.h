#include "Complex.h"
#pragma once

class four_eq
{
    public:
        four_eq(double a, double b, double c, double d, double e);
        void calculate2();
    private:
        double a;
        double b;
        double c;
        double d;
        double e;
};
